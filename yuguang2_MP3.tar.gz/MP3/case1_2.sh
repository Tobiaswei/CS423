nice ./work 1024 R 50000 & nice ./work 1024 L 10000
