rmmod mp3

rm node

insmod mp3.ko

mknod node c 100 0


