mknod node c $100 0
chmod +x node
